package client.Decorator;

import javafx.scene.image.Image;

public class AppartmentInsDecorator extends InsuranceDecorator  {

	public AppartmentInsDecorator(InsuranceWindow window)
	{
		super(window);	
	}
	
	@Override
    public void initGui() {
	 	insWindow.initGui(); 
	 	initImage();
    }
 
    public void initImage()
    {
    	Image image=new Image("app.jpg");
    	insWindow.getImage().setImage(image);
    }

}
