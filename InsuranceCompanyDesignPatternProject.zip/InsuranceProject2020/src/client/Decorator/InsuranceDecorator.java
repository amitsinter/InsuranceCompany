package client.Decorator;

import javafx.scene.image.ImageView;

public abstract class InsuranceDecorator implements InsuranceWindow{
	
	InsuranceWindow insWindow;
	
	public InsuranceDecorator(InsuranceWindow window) {
		insWindow = window;
	}

 	@Override
    public void initGui() {
	 	insWindow.initGui(); 
    }
 
 	@Override
    public ImageView getImage() {
	 	return insWindow.getImage(); 
    }
}
