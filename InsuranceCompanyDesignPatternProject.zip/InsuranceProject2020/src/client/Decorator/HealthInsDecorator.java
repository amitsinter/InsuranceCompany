package client.Decorator;

import javafx.scene.image.Image;

public class HealthInsDecorator extends InsuranceDecorator {

	public HealthInsDecorator(InsuranceWindow window) {
		super(window);	}
	
		
		@Override
	    public void initGui() {
		 	insWindow.initGui(); 
		 	initImage();
	    }
	 
	    public void initImage()
	    {
	    	Image image=new Image("healthpic.jpg");
	    	insWindow.getImage().setImage(image);
	    }


}
