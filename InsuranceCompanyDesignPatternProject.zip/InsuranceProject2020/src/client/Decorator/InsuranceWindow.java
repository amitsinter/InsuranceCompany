package client.Decorator;

import javafx.scene.image.ImageView;

public interface InsuranceWindow {
	public ImageView getImage();
	public void initGui();
	//public void setInsuranceType(String type);
}
