package client.Decorator;

import javafx.scene.image.Image;

public class LifeInsDecorator extends InsuranceDecorator  {

	public LifeInsDecorator(InsuranceWindow window) 
	{
		super(window);		}
	
	@Override
    public void initGui() {
	 	insWindow.initGui(); 
	 	initImage();
    }
 
    public void initImage()
    {
    	Image image=new Image("Lifepic.jpg");
    	insWindow.getImage().setImage(image);
    }

}
