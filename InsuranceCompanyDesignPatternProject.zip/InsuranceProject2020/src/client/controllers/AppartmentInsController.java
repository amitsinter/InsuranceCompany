package client.controllers;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;

import client.MySqlConnection;
import client.purcheases;
import client.DaoDesignPattern.DaoInsurance;
import client.DaoDesignPattern.QueryEntityForDao;
import client.Decorator.AppartmentInsDecorator;

import client.Decorator.InsuranceWindow;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class AppartmentInsController implements InsuranceWindow {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label usernametxt;

    @FXML
    private JFXTextField firstnametxt;

    @FXML
    private JFXTextField lastnametxt;

    @FXML
    private JFXDatePicker datetxt;

    @FXML
    private JFXTextField remarksTxt;

    @FXML
    private JFXDatePicker endDatetxt;

    @FXML
    private JFXButton backbtn;

    @FXML
    private JFXButton saveButton;

    @FXML
    private Label jsonlabel;
    @FXML
    public static String arr[]=new String[5];
    @FXML
    private ImageView apppic;
    @FXML
    void pressback(MouseEvent event) 
    {
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/MainWin.fxml");
    }

    @FXML
    void updateChange(ActionEvent event)
    {
    	QueryEntityForDao PurchasecustomerQuery = new QueryEntityForDao();
    	String firstname=firstnametxt.getText();
    	String lastname=lastnametxt.getText();
    	String remarks=remarksTxt.getText();
    	String type_of_insurance="Appartment";
    	LocalDate date=datetxt.getValue();
    	LocalDate end_date=endDatetxt.getValue();
    	String date1=date.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
    	String endDate=end_date.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
    	arr[0]=firstname;	
    	arr[1]=lastname;	
    	arr[2]=type_of_insurance;	
    	arr[3]=date1;	
    	long days;
/* checks for the input from the user */
    	
    	if(firstname.isEmpty()||lastname.isEmpty()||date1.isEmpty()||remarks.isEmpty()||endDate.isEmpty())
    		ClientMessages.popUp(AlertType.ERROR,"ERROR","You have Empty fields!","Fill all the fields!");
    	else if(!HelpTools.isValidDate(date))
    		ClientMessages.popUp(AlertType.ERROR, "Date Error", "Date ERROR", "Date IS NOT LEGALE");
    	else if(!HelpTools.isValidDate(end_date))
    		ClientMessages.popUp(AlertType.ERROR, "Date Error", "Date ERROR", "Date IS NOT LEGALE");
    	else if(!firstname.matches("[a-zA-Z]+"))
    		ClientMessages.popUp(AlertType.ERROR, "First Name","First name not valid","");
    	else if(!lastname.matches("[a-zA-Z]+"))
    		ClientMessages.popUp(AlertType.ERROR, "Last Name","Last name not valid","");
    	else{
    		days=HelpTools.InsurancePeriod(date,end_date);
    	arr[4]="Total time of Ins: "+days+" days"+ ", "+remarks;
		String customerQuery="INSERT INTO insurance.deatails VALUES('"+arr[0]+"','"+arr[1]+"','"+arr[2]+"','"+arr[3]+"','"+arr[4]+"');";
		/*for Dao design pattern*/
		DaoInsurance dao=new DaoInsurance();
		PurchasecustomerQuery.setQuery(customerQuery);
		dao.InsertOrUpdate(PurchasecustomerQuery);
		
		
		purcheases save=new purcheases(firstname,lastname,type_of_insurance,date1,"Total time of Ins: "+days+" days"+ ", "+remarks);
		HelpTools.CreateLogger(save);
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/MainWin.fxml");
    	}
    }

    @FXML
    void initialize() throws ParseException 
    {
    	/*Decorator design pattern*/
    	InsuranceWindow decorator = new AppartmentInsDecorator(this);
    	decorator.initGui();
    	
        assert usernametxt != null : "fx:id=\"usernametxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert firstnametxt != null : "fx:id=\"firstnametxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert lastnametxt != null : "fx:id=\"lastnametxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert datetxt != null : "fx:id=\"datetxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert remarksTxt != null : "fx:id=\"remarksTxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert endDatetxt != null : "fx:id=\"endDatetxt\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert backbtn != null : "fx:id=\"backbtn\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";
        assert saveButton != null : "fx:id=\"saveButton\" was not injected: check your FXML file 'AppartmentInsWin.fxml'.";

    }
  
	public ImageView getImage() {
		return apppic;
	}

	public void initGui() {
		/* Json File*/
    	JSONParser parser = new JSONParser();
		
		Object obj;
		try {
			obj = parser.parse(new FileReader("src\\Name.json"));
			JSONObject jsonObject = (JSONObject)obj;
			String ver = (String) jsonObject.get("version");
			String stud1 = (String) jsonObject.get("student_name_1");
			String stud2 = (String) jsonObject.get("student_name_2");
			jsonlabel.setText("Version " + ver + "\nDesigned and developed by:\n"+ stud1 + ", "+ stud2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
