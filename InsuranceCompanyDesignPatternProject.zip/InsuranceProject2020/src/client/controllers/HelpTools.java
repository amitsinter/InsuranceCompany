package client.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import com.opencsv.CSVWriter;

import client.purcheases;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.Window;

public class HelpTools {

enum Insu_type {
	car,
	life,
	health,
	appartment,
};
	/**
	 * @author Itamar Gino.
	 * @author Amit Sinter.
	 * 
	 * @param rs
	 * @param NumOfCol
	 * @return ArrayList<String>
	 * 
	 * disassembling the information given by the ResultSet rs
	 */
//	public static ArrayList<String> disassemble(ResultSet rs,int NumOfCol)
//	{
//		ArrayList<String> returnString = new ArrayList<String>();
//		try {
//			while(rs.next())
//			{
//				// Attention ! must run from 1 to NumOfCol (Not from zero)
//				for(int i=1 ; i <= NumOfCol; i++)
//					returnString.add(rs.getString(i));
//			}
//			rs.close();
//			return returnString;
//		} catch (SQLException e)
//		{
//			System.out.println("ClientTools.disassemble() - int NumOfCol Error");
//			e.printStackTrace();
//		}
//		return returnString;
//	}

	/**
	 * @author Itamar Gino.
	 * @author Amit Sinter.
	 * 
	 * @param window
	 * @param fxml
	 * 
	 * 
	 * change screen
	 */

	public static void changeWindow(Window window,String fxml) {
		
		
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				window.hide();
				
				try {
					
					
					BorderPane  root = FXMLLoader.load(getClass().getResource(fxml));
					Scene scene=new Scene(root);
					Stage primaryStage= new Stage();
					primaryStage.setScene(scene);
					primaryStage.show();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
		});
	
	
	}

	
	
	 /* checking if the date from the user is the current day or after*/
	public static boolean isValidDate(LocalDate date)
	{
		
		if(date.isEqual(LocalDate.now())||date.isAfter(LocalDate.now()))
			return true;
	
		return false;
	}
	/* This function calculate the total days between the startDate and the EndDate*/
	public static long InsurancePeriod(LocalDate Startdate,LocalDate Enddate)
	{
		return ChronoUnit.DAYS.between(Startdate, Enddate);
	}
	
	/* This function create the logger file*/
	public static void CreateLogger(purcheases info)
	{
		CSVWriter writer;
			File file=new File("logger.csv");
			boolean flag=file.exists();
			
			FileWriter outputfile;
		
			try {
				outputfile = new FileWriter(file,true);
				writer = new CSVWriter(outputfile);
				String [] Lines= {"Name","FamilyName","Date","Remarks","Insurance Type"};
				if(!flag)
				{
					writer.writeNext(Lines);
				}
				String[] data = { info.getFirstname(), info.getLastname(), info.getPurchaseCurrentDate(), info.getRemarks(), info.getPurchaseType() }; 
		        writer.writeNext(data);
		        writer.close();
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	 
		
	}


	
	
	public static Object[] inputstreamToByteArray(ResultSet rs,String col) {
		int direct;
		int count=0;
		byte[] contents=new byte[400000000];
		InputStream is;
		try {
			is = rs.getBinaryStream(col);

		while ((direct = is.read(contents)) >= 0)
			count+=direct;
		is.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		Object[] ob=new Object[2];
		ob[0]=contents;
		ob[1]=count;
		return ob;
	}
}
