package client.controllers;

import java.io.File;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;



//import common.controllers.Message;
//import common.controllers.ReturnMsgType;
//import common.entities.City;
//import common.entities.Site;
//import common.entities.Tour;
//import common.entities.User;
//import common.entities.ZipVersion;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import client.MySqlConnection;

/*** @author Shahar Ronen.
 * @author Dorin Segall.
 * @author Remez David.
 * @author Itamar Gino.
 * @author Amit Sinte
 * The next class receives information from the server and send it to the client.
�*In each message, you can send to the client any object that needs to be continued -
 *you can send information back to the controller, use the POPUP method to display client information,
 *and transfer data from db to screens.
 * 
 * */


public class ClientMessages {


	public static String username;
	public static String role;
	//public static User user;
	public static String ListOfPurchaseHistory;//

	/*** popUp -
	 * The next method receives 3 strings and 1 AlertType and make from them a popUp massege to the user
	 * The method display the massege on the screen.
	 * 
	 * */
	public static void popUp(AlertType type,String title,String head,String content)
	{

		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				Alert alert=new Alert(type);
				alert.setTitle(title);
				alert.setHeaderText(head);
				alert.setContentText(content); 
				alert.showAndWait();
			}
		});
	}
	/*** messageFromServer -
	 * The next method receives 1 Object and , divides all actions into cases according to Operationtype
	 * and use the Object to perform the operation and after send a massege to the client with the appropriate details 
	 * */
	
}