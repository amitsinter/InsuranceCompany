package client.controllers;

import com.jfoenix.controls.JFXButton;

import client.MySqlConnection;
import client.purcheases;
import client.DaoDesignPattern.DaoInsurance;
import client.DaoDesignPattern.QueryEntityForDao;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class PurchaseController {
	static PurchaseController Instance;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private Label jsonlabel;
    @FXML
    private TableView<client.purcheases> PurchaseHistoryTable;

    @FXML
    private JFXButton backbtn;
    ResultSet requestData;
    ArrayList<client.purcheases> arrString=new ArrayList<client.purcheases>();
    @FXML
    void PressBack(ActionEvent event)
    {
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/MainWin.fxml");
    }
    public void SetDataOnScreen() throws SQLException 
    {

		
		// dataToSend containing all the data!
		// Inserting to viewTable:
		ObservableList<client.purcheases> ol = FXCollections.observableArrayList(arrString);

		// Creating the Table: (setCellValueFactory => must be as RequestDetails attributes are!)
		TableColumn<client.purcheases,String> FirstNameCol = new TableColumn<client.purcheases,String>("First Name");
		FirstNameCol.setStyle("-fx-alignment: CENTER");
		FirstNameCol.setMinWidth(50);
		FirstNameCol.setCellValueFactory(new PropertyValueFactory<client.purcheases, String>("firstname"));
		
		TableColumn<client.purcheases,String> LastNameCol = new TableColumn<client.purcheases,String>("Last Name");
		LastNameCol.setStyle("-fx-alignment: CENTER");
		LastNameCol.setMinWidth(50);
		LastNameCol.setCellValueFactory(new PropertyValueFactory<client.purcheases, String>("lastname"));
		
		TableColumn<client.purcheases,String> purchaseTypeCol = new TableColumn<client.purcheases,String>("Ins Type");
		purchaseTypeCol.setMinWidth(50);
		purchaseTypeCol.setStyle("-fx-alignment: CENTER");
		purchaseTypeCol.setCellValueFactory(new PropertyValueFactory<client.purcheases, String>("purchaseType"));
		
		TableColumn<client.purcheases,String> purchaseDateCol = new TableColumn<client.purcheases,String>("Date");
		purchaseDateCol.setMinWidth(50);
		purchaseDateCol.setStyle("-fx-alignment: CENTER");
		purchaseDateCol.setCellValueFactory(new PropertyValueFactory<client.purcheases, String>("PurchaseCurrentDate"));
		
		TableColumn<client.purcheases,String> RemarksCol = new TableColumn<client.purcheases,String>("Remarks");
		RemarksCol.setMinWidth(200);
		RemarksCol.setStyle("-fx-alignment: CENTER");
		RemarksCol.setCellValueFactory(new PropertyValueFactory<client.purcheases, String>("remarks"));
		
		PurchaseHistoryTable.setItems(ol);
		PurchaseHistoryTable.getColumns().addAll(FirstNameCol,LastNameCol,purchaseTypeCol,purchaseDateCol,RemarksCol);
		PurchaseHistoryTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		//PurchaseHistoryTable.getItems().setAll(dataToSend);
    }

    @FXML
    void initialize() throws SQLException, ParseException 
    {
    	QueryEntityForDao PurchasecustomerQuery = new QueryEntityForDao();
    	Instance=this;
    	/* Json File*/
    	JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("C:\\Users\\Amit\\eclipse-workspace\\InsuranceProject2020\\src\\Name.json"));
			JSONObject jsonObject = (JSONObject)obj;
			String ver = (String) jsonObject.get("version");
			String stud1 = (String) jsonObject.get("student_name_1");
			String stud2 = (String) jsonObject.get("student_name_2");
			jsonlabel.setText("Version " + ver + "\nDesigned and developed by:\n"+ stud1 + ", "+ stud2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    
    	String GetAllPurchases = "SELECT * FROM insurance.deatails" ;
    	PurchasecustomerQuery.setQuery(GetAllPurchases);
    	/*requestData=MySqlConnection.getQuery(GetAllPurchases);  */ 
    	DaoInsurance dao=new DaoInsurance();
		
		
    	arrString = dao.GetQueryAfterDivision(PurchasecustomerQuery);
    	SetDataOnScreen();
    	assert PurchaseHistoryTable != null : "fx:id=\"PurchaseHistoryTable\" was not injected: check your FXML file 'PurchesesWin.fxml'.";
        assert backbtn != null : "fx:id=\"backbtn\" was not injected: check your FXML file 'PurchesesWin.fxml'.";

    }
}
