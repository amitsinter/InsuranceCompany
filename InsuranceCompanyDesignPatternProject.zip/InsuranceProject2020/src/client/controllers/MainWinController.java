package client.controllers;

import com.jfoenix.controls.JFXButton;

import client.MySqlConnection;
import client.controllers.HelpTools.Insu_type;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ResourceBundle;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainWinController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private BorderPane barChart;

    @FXML
    private JFXButton ApartmentIns;

    @FXML
    private JFXButton CarIns;

    @FXML
    private JFXButton HealthIns;

    @FXML
    private ImageView MainPic;
    @FXML
    private JFXButton LIfeIns;
    @FXML
    private Label jsonlabel;
    @FXML
    private JFXButton ViewPurchases;
    public static String arr[]=new String[5];
    @FXML
   
    void GoToAllPurchases(ActionEvent event) {

    
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/PurchesesWin.fxml");
	    
    }
    

    @FXML
    void GoToAppartmentIns(MouseEvent event)
    {
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/AppartmentInsWin.fxml");

    }
   
    @FXML
    void GoToCarIns(MouseEvent event) 
    {
    	
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/CarInsuranceWin.fxml");

    }

    @FXML
    void GoToHealthIns(MouseEvent event) 
    {
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/HealtInsWin.fxml");

    }

    @FXML
    void GoToLifeIns(MouseEvent event) 
    {
    	HelpTools.changeWindow((Stage)((Node)event.getSource()).getScene().getWindow(), "/client/boundry/LifeInsWin.fxml");

    }

    @FXML
    void initialize() throws org.json.simple.parser.ParseException, ParseException 
    {
    	Image image=new Image("images.png");
		MainPic.setImage(image);
    	/* Json File*/
    	JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("C:\\Users\\Amit\\eclipse-workspace\\InsuranceProject2020\\src\\Name.json"));
			JSONObject jsonObject = (JSONObject)obj;
			String ver = (String) jsonObject.get("version");
			String stud1 = (String) jsonObject.get("student_name_1");
			String stud2 = (String) jsonObject.get("student_name_2");
			jsonlabel.setText("Version " + ver + "\nDesigned and developed by:\n"+ stud1 + ", "+ stud2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* end Json File*/
	
        assert barChart != null : "fx:id=\"barChart\" was not injected: check your FXML file 'MainWin.fxml'.";
        assert ApartmentIns != null : "fx:id=\"ApartmentIns\" was not injected: check your FXML file 'MainWin.fxml'.";
        assert CarIns != null : "fx:id=\"CarIns\" was not injected: check your FXML file 'MainWin.fxml'.";
        assert HealthIns != null : "fx:id=\"HealthIns\" was not injected: check your FXML file 'MainWin.fxml'.";
        assert LIfeIns != null : "fx:id=\"LIfeIns\" was not injected: check your FXML file 'MainWin.fxml'.";
        assert ViewPurchases != null : "fx:id=\"ViewPurchases\" was not injected: check your FXML file 'MainWin.fxml'.";

    }
}
