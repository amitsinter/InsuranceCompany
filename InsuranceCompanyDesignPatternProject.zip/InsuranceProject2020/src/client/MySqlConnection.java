package client;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TimeZone;


//import common.controllers.Message;
//import common.ocsf.server.ConnectionToClient;
import javafx.scene.control.Alert.AlertType;


public class MySqlConnection 
{
			private static MySqlConnection _instance = new MySqlConnection();
			private  Connection conn=null;
			
			 private MySqlConnection()
			 {
				 try {
						Class.forName("com.mysql.cj.jdbc.Driver");
					} catch (Exception ex) {/*handle exception*/}

					
					
					try {
						conn = DriverManager.getConnection("jdbc:mysql://localhost/insurance?serverTimezone=IST","root","Aa123456");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					System.out.println("SQL Connection Succeed !");
					

			 }
	  
			 public Connection getConnection() 
			 {
			      return conn;
			 }
			 
			 public static MySqlConnection getInstance()
			 {
				 return _instance;
			 }


			
		
	}
				
		
			
		


