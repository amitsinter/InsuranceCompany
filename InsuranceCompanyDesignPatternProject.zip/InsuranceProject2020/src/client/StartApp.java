package client;


import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Logger;

//import com.itextpdf.layout.element.Image;
import javafx.scene.image.Image;
//import client.controllers.MainViewController;
//import common.controllers.Message;
//import common.controllers.enums.OperationType;
//import common.entity.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
public class StartApp extends Application
{
	 
	
	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		try {
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(getClass().getResource("/client/boundry/MainWin.fxml"));
			BorderPane	root = fxmlLoader.load();
			Scene scene = new Scene(root,800,600);
			primaryStage.setScene(scene);
			//primaryStage.getIcons().add(new Image("images.png"));
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	 public static void main(String[] args) 
	 {
		
	      /* end check */
	    
	      launch(args);
	     
	    	 
			
	}
}
