package client.DaoDesignPattern;

import java.sql.ResultSet;
import java.util.ArrayList;

import client.purcheases;

public interface DaoDesignPatternInsurance
{
	public  void InsertOrUpdate (QueryEntityForDao customerQuery);
	public  ArrayList<client.purcheases> GetQueryAfterDivision(QueryEntityForDao customerQuery);
}
