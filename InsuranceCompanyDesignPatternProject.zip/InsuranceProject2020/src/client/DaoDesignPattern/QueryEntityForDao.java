package client.DaoDesignPattern;



public class QueryEntityForDao {
	private String query;
	
	
	
	public QueryEntityForDao(String query)
	{
		this.query = query;
	
	}
	public QueryEntityForDao() 
	{
		// TODO Auto-generated constructor stub
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}

}
