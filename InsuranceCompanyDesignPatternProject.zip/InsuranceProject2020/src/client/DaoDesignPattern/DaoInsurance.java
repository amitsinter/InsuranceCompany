package client.DaoDesignPattern;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import client.MySqlConnection;
import client.purcheases;


public class DaoInsurance implements DaoDesignPatternInsurance 
{
	
	
//	private static DaoInsurance instance = new DaoInsurance();
	//private Connection connection;
	public static MySqlConnection conn;
	
	public DaoInsurance() {

			conn=MySqlConnection.getInstance();
		
	}
	


	public void InsertOrUpdate(QueryEntityForDao customerQuery)
	{
		Statement stmt = null;
		try {
			stmt = conn.getConnection().createStatement();
			String query_for_Dao=customerQuery.getQuery();
			stmt.executeUpdate(query_for_Dao);
			System.out.println("my sql "+ query_for_Dao);
		}
		catch (SQLException e) {
			System.out.println("insert or update exception !");
		}
		
		
	}
	public  ArrayList<client.purcheases> GetQueryAfterDivision(QueryEntityForDao customerQuery)
	{
		ResultSet requestData;
		requestData=getQuery(customerQuery.getQuery());
		ArrayList<String> arrString=new ArrayList<String>();
		arrString = disassemble(requestData, 5);
		ArrayList<client.purcheases> dataToSend = new ArrayList<client.purcheases>();//done
		int jump=0;
		for(int i=0;i<arrString.size()/5;i++)
		{
			
			client.purcheases rd = new client.purcheases(arrString.get(jump+0),arrString.get(jump+1),arrString.get(jump+2),arrString.get(jump+3),arrString.get(jump+4));
			dataToSend.add(rd);
			jump+=5;
		}
		return dataToSend;
	}

	
	public ResultSet getQuery(String query)
	{
		ResultSet rs=null;
		try {
			Statement stmt= conn.getConnection().createStatement();
			rs=stmt.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
	}
	public static ArrayList<String> disassemble(ResultSet rs,int NumOfCol)
	{
		ArrayList<String> returnString = new ArrayList<String>();
		try {
			while(rs.next())
			{
				// Attention ! must run from 1 to NumOfCol (Not from zero)
				for(int i=1 ; i <= NumOfCol; i++)
					returnString.add(rs.getString(i));
			}
			rs.close();
			return returnString;
		} catch (SQLException e)
		{
			System.out.println("ClientTools.disassemble() - int NumOfCol Error");
			e.printStackTrace();
		}
		return returnString;
	}
	
	

}
