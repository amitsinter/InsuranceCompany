package client;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class purcheases 
{
	
	public String firstname;
	public String lastname;
	public String purchaseType;
	public String PurchaseCurrentDate;
	public String remarks;

	public purcheases(String firstname,String lastname,String purchaseType,String PurchaseCurrentDate, String remarks ) 
	{
		this.firstname=firstname;
		this.purchaseType=purchaseType;
		this.lastname=lastname;
		this.PurchaseCurrentDate=PurchaseCurrentDate;
		this.remarks=remarks;
	}
	public purcheases(ResultSet rs) throws SQLException 
	{
		firstname=rs.getString("First Name");
		lastname=rs.getString("Last Name");
		purchaseType=rs.getString("Ins Type");
		PurchaseCurrentDate=rs.getString("Date");
		remarks=rs.getString("Remarks");
	}

	@Override
	public String toString() {
		return "purcheases [firstname=" + firstname + ", lastname=" + lastname + ", purchaseType=" + purchaseType
				+ ", PurchaseCurrentDate=" + PurchaseCurrentDate + ", remarks=" + remarks + "]";
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
	public String getPurchaseCurrentDate() {
		return PurchaseCurrentDate;
	}
	public void setPurchaseCurrentDate(String purchaseCurrentDate) {
		PurchaseCurrentDate = purchaseCurrentDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
   
	
	
}
